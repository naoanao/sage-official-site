"""
Sage Blog Auto-Scheduler
- Pulls topics from Notion Content Pool (Category=blog, Status=予約済み)
- Generates English Markdown article via Groq (llama-3.3-70b-versatile)
- Saves to src/blog/posts/YYYY-MM-DD-{slug}.mdx with frontmatter
- git add → commit → push
- Updates Notion status to 完了
- Adds Bluesky post to SNS job queue with blog URL
"""

import os
import logging
import re
import subprocess
from datetime import datetime, timezone

logger = logging.getLogger("BlogScheduler")

from backend.data.jobs_store import append as _jobs_append

GROQ_MODEL = "llama-3.3-70b-versatile"
POSTS_DIR = "src/blog/posts"
SAGE_BASE_URL = os.getenv("SAGE_BASE_URL") or os.getenv("SITE_URL", "https://your-pages-site.pages.dev")


def _load_identity() -> dict:
    """identity.jsonを読み込む。失敗時はデフォルト値を返す"""
    import json
    try:
        path = os.path.join(os.path.dirname(os.path.dirname(__file__)), "config", "identity.json")
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {
            "role": "AI content creator",
            "niche": "AI tools and automation",
            "tone": "professional yet approachable",
            "brand_name": "Sage AI",
            "target_audience": "solopreneurs and developers",
            "language": "en",
        }


class BlogScheduler:
    def __init__(self):
        from groq import Groq
        from backend.modules.notion_content_pool import NotionContentPool
        from backend.integrations.devto_integration import DevToIntegration

        self.groq = Groq(api_key=os.getenv("GROQ_API_KEY"))
        self.notion = NotionContentPool()
        self.devto = DevToIntegration()
        self.dry_run = os.getenv("SAGE_DRY_RUN", "False").lower() == "true"
        self.identity = _load_identity()
        logger.info(f"[BLOG] BlogScheduler initialized. identity={self.identity.get('niche')} dry_run={self.dry_run}")

    # ── Notion helpers ────────────────────────────────────────────────────────

    def _get_blog_topics(self, limit: int = 1) -> list:
        """Return Notion items with Category=blog and Status=予約済み|Ready."""
        import requests as _requests

        token = os.getenv("NOTION_API_KEY") or os.getenv("NOTION_TOKEN")
        db_id = os.getenv("NOTION_CONTENT_POOL_DB_ID")
        if not token or not db_id:
            logger.error("[BLOG] NOTION_API_KEY or NOTION_CONTENT_POOL_DB_ID missing")
            return []

        headers = {
            "Authorization": f"Bearer {token}",
            "Notion-Version": "2022-06-28",
            "Content-Type": "application/json",
        }
        query_body = {
            "filter": {
                "and": [
                    {"property": "Status", "select": {"equals": "予約済み"}},
                    {"property": "Category", "select": {"equals": "blog"}},
                ]
            },
            "page_size": limit,
        }
        try:
            resp = _requests.post(
                f"https://api.notion.com/v1/databases/{db_id}/query",
                headers=headers,
                json=query_body,
                timeout=15,
            )
            resp.raise_for_status()
            return resp.json().get("results", [])
        except Exception as e:
            logger.error(f"[BLOG] Notion query failed: {e}")
            return []

    def _update_notion_status(self, page_id: str, status: str) -> None:
        import requests as _requests

        token = os.getenv("NOTION_API_KEY") or os.getenv("NOTION_TOKEN")
        headers = {
            "Authorization": f"Bearer {token}",
            "Notion-Version": "2022-06-28",
            "Content-Type": "application/json",
        }
        try:
            _requests.patch(
                f"https://api.notion.com/v1/pages/{page_id}",
                headers=headers,
                json={"properties": {"Status": {"select": {"name": status}}}},
                timeout=10,
            )
            logger.info(f"[BLOG] Notion page {page_id} status → {status}")
        except Exception as e:
            logger.error(f"[BLOG] Notion status update failed: {e}")

    # ── Article generation ────────────────────────────────────────────────────

    def _extract_topic(self, notion_page: dict) -> str:
        props = notion_page.get("properties", {})
        for key in ("Topic", "Name", "Title", "Content", "テーマ", "タイトル"):
            prop = props.get(key, {})
            # title type
            if prop.get("type") == "title":
                rich = prop.get("title", [])
                if rich:
                    return rich[0].get("plain_text", "")
            # rich_text type
            if prop.get("type") == "rich_text":
                rich = prop.get("rich_text", [])
                if rich:
                    return rich[0].get("plain_text", "")
        return ""

    def _extract_evidence_status(self, notion_page: dict) -> str:
        """Return EvidenceStatus rich_text value, or '' if not present."""
        prop = notion_page.get("properties", {}).get("EvidenceStatus", {})
        if prop.get("type") == "rich_text":
            rich = prop.get("rich_text", [])
            if rich:
                return rich[0].get("plain_text", "")
        return ""

    def _generate_article(self, topic: str, evidence_status: str = "") -> dict:
        today = datetime.now(timezone.utc).strftime("%Y-%m-%d")
        slug_base = re.sub(r"[^a-z0-9]+", "-", topic.lower())[:50].strip("-")
        slug = f"{today}-{slug_base}"

        # identity.jsonからニッチ・ターゲット・トーンを動的に読み込む
        identity = _load_identity()
        niche = identity.get("niche", "AI tools and automation")
        role = identity.get("role", "AI content creator")
        tone = identity.get("tone", "professional yet approachable")
        target = identity.get("target_audience", "solopreneurs and developers")
        brand = identity.get("brand_name", "Sage AI")
        lang = identity.get("language", "en")

        lang_instruction = "Write in Japanese." if lang == "ja" else "Write in English."

        system_prompt = (
            f"You are {brand}, a world-class content writer specializing in {niche}. "
            f"Your role: {role}. Your tone: {tone}. "
            f"Your target audience: {target}. "
            f"{lang_instruction} "
            "Write compelling, SEO-optimized blog posts with clear headings, real examples, and actionable takeaways."
        )
        user_prompt = f"""Write a detailed blog post (1500+ words) on the topic: "{topic}"

Return ONLY valid Markdown with this exact frontmatter at the top:
---
title: "TITLE_HERE"
date: "{today}"
slug: "{slug}"
excerpt: "ONE SENTENCE SUMMARY"
keywords: "keyword1, keyword2, keyword3"
author: "Sage AI"
---

Then write the full article body in Markdown. Use ## for sections, include bullet lists.

MANDATORY: End EVERY article with this exact CTA section (adapt wording naturally, keep the links):

## Want to Build This System Yourself?

**Sage 3.0 Developer Blueprint** is the complete technical guide to building an autonomous content engine like this one — the exact stack running in production since January 2026.

- ⚙️ Full Flask + LangGraph + CrewAI codebase
- ⚙️ Cloudflare Workers for 24/7 posting (no PC required)
- ⚙️ Auto-setup script + connection verifier with AI diagnosis
- ⚙️ Half a day to deploy. Runs forever after that.

**[$49 — Get the Developer Blueprint →](https://naofumi3.gumroad.com/l/apvbzh)**

One-time purchase. Your code, your keys, your data."""

        resp = self.groq.chat.completions.create(
            model=GROQ_MODEL,
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt},
            ],
            max_tokens=3000,
            temperature=0.7,
        )
        raw = resp.choices[0].message.content.strip()

        # Extract actual title from frontmatter for nicer slug
        title_match = re.search(r'^title:\s*["\']?(.+?)["\']?\s*$', raw, re.MULTILINE)
        title = title_match.group(1) if title_match else topic

        return {"slug": slug, "title": title, "body": raw, "date": today, "evidence_status": evidence_status}

    # ── File / git helpers ────────────────────────────────────────────────────

    def _save_mdx(self, article: dict) -> str:
        os.makedirs(POSTS_DIR, exist_ok=True)
        filename = f"{article['slug']}.mdx"
        filepath = os.path.join(POSTS_DIR, filename)
        body = article["body"]
        ev = article.get("evidence_status", "")
        if ev and body.startswith("---"):
            # Inject evidence_status into frontmatter before closing ---
            parts = body.split("---", 2)
            if len(parts) == 3:
                body = f"---{parts[1]}evidence_status: {ev}\n---{parts[2]}"
        with open(filepath, "w", encoding="utf-8") as f:
            f.write(body)
        logger.info(f"[BLOG] Saved: {filepath}")
        return filepath

    def _git_push(self, filepath: str, title: str) -> bool:
        try:
            subprocess.run(["git", "add", filepath], check=True)
            subprocess.run(
                ["git", "commit", "-m", f"feat: auto-publish blog post '{title}'"],
                check=True,
            )
            subprocess.run(["git", "push", "origin", "main"], check=True)
            logger.info("[BLOG] git push complete.")
            return True
        except subprocess.CalledProcessError as e:
            logger.error(f"[BLOG] git error: {e}")
            return False

    # ── SNS queue helper ──────────────────────────────────────────────────────

    def _queue_sns_post(self, title: str, slug: str) -> None:
        url = f"{SAGE_BASE_URL}/blog/{slug}"
        bs_text = f"📖 New post: {title}\n{url}"

        # Generate blog header image (Gemini → LoremFlickr fallback)
        image_url = None
        try:
            from backend.integrations.image_generation import image_gen_enhanced
            image_url = image_gen_enhanced.generate_blog_image(title)
            logger.info(f"[BLOG] Image generated: {image_url[:60]}")
        except Exception as e:
            logger.warning(f"[BLOG] Image generation skipped: {e}")

        job = {
            "id": f"blog_{slug}_{datetime.utcnow().strftime('%Y%m%d%H%M%S')}",
            "type": "pr_post",
            "targets": ["bluesky"],
            "topic": title,
            "ig_caption": "",
            "bs_text": bs_text,
            "image_path": image_url,
            "status": "pending",
            "created_at": datetime.utcnow().isoformat(),
        }
        _jobs_append(job)
        logger.info(f"[BLOG] Queued SNS post for blog: {url}")

    # ── Dev.to publisher ─────────────────────────────────────────────────────

    def _post_devto(self, article: dict) -> None:
        """Post the article to Dev.to. Strips frontmatter before sending."""
        body = article["body"]
        # Strip YAML frontmatter (--- ... ---) before posting
        if body.startswith("---"):
            parts = body.split("---", 2)
            content = parts[2].strip() if len(parts) == 3 else body
        else:
            content = body

        # Build tags from identity niche keywords (Dev.to max 4 tags, lowercase, no spaces)
        niche = self.identity.get("niche", "")
        tag_map = {
            "developer": ["ai", "python", "automation", "productivity"],
            "python": ["python", "ai", "automation", "programming"],
            "solopreneur": ["ai", "automation", "productivity", "business"],
            "automation": ["automation", "ai", "python", "productivity"],
            "finance": ["ai", "finance", "automation", "productivity"],
            "fitness": ["ai", "fitness", "automation", "health"],
        }
        tags = ["ai", "automation", "productivity", "python"]  # default
        for kw, t in tag_map.items():
            if kw in niche.lower():
                tags = t
                break

        # canonical_urlでSageサイトをオリジナルとして指定（SEO保護）
        canonical = f"{SAGE_BASE_URL}/blog/{article.get('slug', '')}"

        result = self.devto.post_article(
            title=article["title"],
            content_markdown=content,
            tags=tags,
            published=True,
            canonical_url=canonical,
        )
        if result.get("status") == "success":
            logger.info(f"[BLOG] ✅ Dev.to published: {result.get('url')}")
        else:
            logger.warning(f"[BLOG] Dev.to post skipped/failed: {result.get('message', result)}")

    # ── Main ──────────────────────────────────────────────────────────────────

    def _auto_topic(self) -> str | None:
        """Use Groq to generate a trending blog topic when Notion queue is empty."""
        existing = []
        posts_dir = POSTS_DIR
        if os.path.isdir(posts_dir):
            existing = [os.path.splitext(f)[0] for f in os.listdir(posts_dir) if f.endswith(".mdx")]

        existing_str = "\n".join(existing[-10:]) if existing else "(none)"
        prompt = f"""You are a content strategist for an AI solopreneur blog targeting English-speaking creators.
Suggest ONE fresh, specific, high-value blog post topic about AI automation, monetization, or solopreneur growth for 2026.
The topic must be different from these recent posts:
{existing_str}

Respond with ONLY the topic title, nothing else. Make it specific and compelling (e.g. "5 AI Tools That Replace a $10K/Month VA in 2026")."""

        try:
            resp = self.groq.chat.completions.create(
                model=GROQ_MODEL,
                messages=[{"role": "user", "content": prompt}],
                max_tokens=80,
                temperature=0.9,
            )
            topic = resp.choices[0].message.content.strip().strip('"').strip("'")
            logger.info(f"[BLOG] Auto-generated topic: '{topic}'")
            return topic
        except Exception as e:
            logger.error(f"[BLOG] Auto-topic generation failed: {e}")
            return None

    def run_once(self) -> None:
        logger.info("[BLOG] run_once() started.")
        items = self._get_blog_topics(limit=1)

        page_id = None
        ev_status = ""
        if not items:
            logger.info("[BLOG] No blog topics in Notion queue. Trying auto-topic generation...")
            topic = self._auto_topic()
            if not topic:
                logger.info("[BLOG] Auto-topic failed. Idle.")
                return
        else:
            page = items[0]
            page_id = page["id"]
            topic = self._extract_topic(page)
            # Phase C: evidence_status gate — skip FAILED topics
            ev_status = self._extract_evidence_status(page)
            if ev_status == "FAILED":
                logger.warning(f"[BLOG] Skipping '{topic}' (evidence_status=FAILED)")
                return
        if not topic:
            logger.warning("[BLOG] Could not extract topic from Notion page.")
            return

        logger.info(f"[BLOG] Generating article for: '{topic}'")

        if self.dry_run:
            logger.info(f"[BLOG][DRY_RUN] Would generate article for '{topic}'. Skipping.")
            return

        article = self._generate_article(topic, evidence_status=ev_status)
        filepath = self._save_mdx(article)
        pushed = self._git_push(filepath, article["title"])

        if pushed:
            if page_id:
                self._update_notion_status(page_id, "完了")
            self._queue_sns_post(article["title"], article["slug"])
            self._post_devto(article)
            logger.info(f"[BLOG] ✅ Article published: {article['slug']}")
        else:
            logger.error("[BLOG] git push failed. Notion status not updated.")

    def run(self) -> None:
        """Background loop: runs at JST 09:00 (UTC 00:00) daily."""
        import time
        logger.info("[BLOG] BlogScheduler background loop started.")
        while True:
            try:
                now_utc = datetime.now(timezone.utc)
                if now_utc.hour == 0 and now_utc.minute < 5:
                    self.run_once()
                    time.sleep(300)  # prevent double-run within the same hour
                else:
                    time.sleep(60)
            except Exception as e:
                logger.error(f"[BLOG] Loop error: {e}")
                time.sleep(60)
